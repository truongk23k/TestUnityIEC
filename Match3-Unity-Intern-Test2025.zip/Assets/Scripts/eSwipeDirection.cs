﻿public enum eSwipeDirection
{
    LEFT,
    RIGHT,
    UP,
    DOWN
}
