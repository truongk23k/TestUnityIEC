﻿public interface IMenu
{
    void Setup(UIMainManager mngr);

    void Show();

    void Hide();
}
